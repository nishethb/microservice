package com.kpmg.iga.migration.idn.util;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class Util {

	public static String getProperty(String a_property) {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("idnparams");
		} catch (Exception e) {
			bundle = ResourceBundle.getBundle("idnparams");
		}
		String property = null;
		if (bundle != null) {
			property = bundle.getString(a_property);
		}
		return property;
	}

	public static String getToken(String tenant) throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();

		// Build the URI with required parameters for token retrieval
		URIBuilder builder = new URIBuilder(tenant);
		builder.setParameter("grant_type", "client_credentials")
				.setParameter("client_id", Util.getProperty("destination.clientID"))
				.setParameter("client_secret", Util.getProperty("destination.clientSecret"));

		// Create an HTTP POST request with the built URI
		HttpPost request = new HttpPost(builder.build());

		// Execute the request to get the token
		HttpResponse response = client.execute(request);

		// Process the response and extract the token
		String resp = "";
		resp = EntityUtils.toString(response.getEntity());
		JSONObject auth = new JSONObject(resp);
		String token = (String) auth.get("access_token");

		// Print the retrieved token
		// System.out.println(token);

		// Return the token
		return token;

	}

	@SuppressWarnings("unused")
	public static String createSrc(String token, String accountCorrelationConfig)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();

		// Define the file path to your JSON file
		
		String filePath = Util.getProperty("sourceJsonFilePath");

		// Read JSON content from the file
		String jsonContent = FileHandling.readJsonFromFile(filePath);
		System.out.println("jsonContent :"+jsonContent);
		// Parse the existing JSON content
		JSONObject jsonObjectaccountCorrelationConfig = new JSONObject(accountCorrelationConfig);
		JSONObject jsonObject = new JSONObject(jsonContent);

		// Add or update the "accountCorrelationConfig" field with the provided value
		jsonObject.put("accountCorrelationConfig", jsonObjectaccountCorrelationConfig);

		// Create an HTTP POST request to the specified URL
		HttpPost post = new HttpPost(Util.getProperty("sourceURL"));

		// Set request headers for content type, accept, and authorization
		post.addHeader("Content-Type", "application/json");
		post.addHeader("Accept", "application/json");
		post.addHeader("Authorization", "Bearer " + token);

		String modifiedJsonContent = jsonObject.toString();
		post.setEntity(new StringEntity(modifiedJsonContent));

		// Execute the request and get the response
		HttpResponse response = client.execute(post);

		// Process the response and get the result
		String result = "";
		result = EntityUtils.toString(response.getEntity());
		// Parse the JSON response to extract the 'id' attribute
		JSONObject jsonResponse = new JSONObject(result);
		System.out.println("jsonResponse :"+jsonResponse);
		String name = jsonResponse.optString("name");

		// Return the 'id' attribute value
		return name;
	}

	public static String getAccountCorForActiveDirectory(String token)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();

		// Define the URL for the GET request
		String url = Util.getProperty("sourceURL"); // Replace with the actual URL

		// Create an HTTP GET request to the specified URL
		HttpGet get = new HttpGet(url);

		// Set request headers for content type, accept, and authorization
		get.addHeader("Content-Type", "application/json");
		get.addHeader("Accept", "application/json");
		get.addHeader("Authorization", "Bearer " + token);

		// Execute the request and get the response
		HttpResponse response = client.execute(get);

		// Process the response and extract the accountCor for active-directory
		String result = EntityUtils.toString(response.getEntity());
		JSONArray jsonArray = new JSONArray(result);

		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String description = jsonObject.optString("description");

			if ("Zurich-Active Directory".equalsIgnoreCase(description)) {
				String accountCor = jsonObject.optString("accountCorrelationConfig");
				// System.out.println(accountCor);
				return accountCor;
			}
		}

		// Return null if no active-directory entry is found
		return null;
	}

	public static String updateDomainConfig(String token, String id)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();
		String jsonPatch = new String(Files.readAllBytes(Paths
				.get(Util.getProperty("domainJsonFilePath")))); //

		// Create an HTTP PATCH request to the specified URL using the 'id'
		HttpPatch patch = new HttpPatch("https://partner4745.api.identitynow-demo.com/v3/sources/" + id);

		// Set request headers for content type, accept, and authorization
		patch.addHeader("Content-Type", "application/json-patch+json");
		patch.addHeader("Authorization", "Bearer " + token);

		// Set the request body with the updated data
		patch.setEntity(new StringEntity(jsonPatch));

		// Execute the PATCH request
		HttpResponse response = client.execute(patch);

		// Process the response and get the result
		String result = "";
		return result = EntityUtils.toString(response.getEntity());
	}

	public static String updateCorrelationConfig(String token, String id)
			throws URISyntaxException, ClientProtocolException, IOException {

		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();
		
		String jsonPatch = new String(Files.readAllBytes(Paths.get(Util.getProperty("updateCorrelationFilePath"))));

		// Create an HTTP POST request to the specified URL
		HttpPost post = new HttpPost("https://partner4745.api.identitynow-demo.com/diana/sources/sources/" + id
				+ "/updateCorrelationConfig");

		// Set request headers for content type, accept, and authorization
		post.addHeader("Content-Type", "application/json");
		post.addHeader("Accept", "application/json");
		post.addHeader("Authorization", "Bearer " + token);
		// Set the request body with the updated data
		post.setEntity(new StringEntity(jsonPatch));

		// Execute the POST request
		HttpResponse response = client.execute(post);

		// Process the response and get the result
		String result = "";
		return result = EntityUtils.toString(response.getEntity());

	}
	
	public static String updateSchema(String token, String sourceId,String schemaID)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();
		String jsonPatch = new String(Files.readAllBytes(Paths
				.get(Util.getProperty("schemaJsonFilePath")))); //

		// Create an HTTP PATCH request to the specified URL using the 'id'
		HttpPatch patch = new HttpPatch("https://partner4745.api.identitynow-demo.com/v3/sources/"+sourceId+"/schemas/"+schemaID);

		// Set request headers for content type, accept, and authorization
		patch.addHeader("Content-Type", "application/json-patch+json");
		patch.addHeader("Authorization", "Bearer " + token);
		System.out.println("jsonPatch :"+jsonPatch);
		// Set the request body with the updated data
		patch.setEntity(new StringEntity(jsonPatch));

		// Execute the PATCH request
		HttpResponse response = client.execute(patch);

		// Process the response and get the result
		String result = "";
		return result = EntityUtils.toString(response.getEntity());
	}

	public static String getSourceID(String token,String sourceName)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();
		String sourceID=null;

		// Define the URL for the GET request
		String url = Util.getProperty("sourceURL"); // Replace with the actual URL

		// Create an HTTP GET request to the specified URL
		HttpGet get = new HttpGet(url);

		// Set request headers for content type, accept, and authorization
		get.addHeader("Content-Type", "application/json");
		get.addHeader("Accept", "application/json");
		get.addHeader("Authorization", "Bearer " + token);

		// Execute the request and get the response
		HttpResponse response = client.execute(get);

		// Process the response and extract the accountCor for active-directory
		String result = EntityUtils.toString(response.getEntity());
		JSONArray jsonArray = new JSONArray(result);

		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String name = jsonObject.optString("name");
			if(name.equalsIgnoreCase(sourceName)) {
				sourceID = (String)jsonObject.get("id");
			}

			
		}

		// Return null if no active-directory entry is found
		return sourceID;
	}

	public static String getAccountSchemaID(String token,String sourceName)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();
		String accountSchemaID=null;

		// Define the URL for the GET request
		String url = Util.getProperty("sourceURL"); // Replace with the actual URL

		// Create an HTTP GET request to the specified URL
		HttpGet get = new HttpGet(url);

		// Set request headers for content type, accept, and authorization
		get.addHeader("Content-Type", "application/json");
		get.addHeader("Accept", "application/json");
		get.addHeader("Authorization", "Bearer " + token);

		// Execute the request and get the response
		HttpResponse response = client.execute(get);

		// Process the response and extract the accountCor for active-directory
		String result = EntityUtils.toString(response.getEntity());
		JSONArray jsonArray = new JSONArray(result);

		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String name = jsonObject.optString("name");
			if(name.equalsIgnoreCase(sourceName)) {
				JSONArray schemaObjArr = (JSONArray)jsonObject.get("schemas");
				for(Object jObj : schemaObjArr) {
					//System.out.println("jObj :"+jObj);
					JSONObject obj = new JSONObject(jObj.toString());
					//System.out.println("obj :"+obj);
					String objName = (String)obj.get("name");
					if(objName != null && objName.equalsIgnoreCase("account")) {
						accountSchemaID = (String)obj.get("id");
					}
					
				}
			}

			
		}

		// Return null if no active-directory entry is found
		return accountSchemaID;
	}
}
