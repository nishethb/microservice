package com.kpmg.iga.migration.idn.util;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileHandling {
	

	// Helper method to read JSON content from a file
	public static String readJsonFromFile(String filePath) throws IOException {
		byte[] bytes = Files.readAllBytes(Paths.get(filePath));
		return new String(bytes, StandardCharsets.UTF_8);
	}

}
