package com.kpmg.iga.migration.idn.source;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import com.kpmg.iga.migration.idn.util.Util;
import com.kpmg.iga.migration.idn.util.FileHandling;

public class SourceOperations {
	
	@SuppressWarnings("unused")
	public static String createSrc(String token, String accountCorrelationConfig)
			throws URISyntaxException, ClientProtocolException, IOException {
		// Initialize an HttpClient for making HTTP requests
		HttpClient client = HttpClientBuilder.create().build();

		// Define the file path to your JSON file
		String migToolHome = getParentDir();
		System.out.println("migToolHome :"+migToolHome);
		String filePath = Util.getProperty("sourceJsonFilePath");

		// Read JSON content from the file
		String jsonContent = FileHandling.readJsonFromFile(filePath);
		System.out.println("jsonContent :"+jsonContent);
		// Parse the existing JSON content
		JSONObject jsonObjectaccountCorrelationConfig = new JSONObject(accountCorrelationConfig);
		JSONObject jsonObject = new JSONObject(jsonContent);

		// Add or update the "accountCorrelationConfig" field with the provided value
		jsonObject.put("accountCorrelationConfig", jsonObjectaccountCorrelationConfig);

		// Create an HTTP POST request to the specified URL
		HttpPost post = new HttpPost(Util.getProperty("sourceURL"));

		// Set request headers for content type, accept, and authorization
		post.addHeader("Content-Type", "application/json");
		post.addHeader("Accept", "application/json");
		post.addHeader("Authorization", "Bearer " + token);

		String modifiedJsonContent = jsonObject.toString();
		post.setEntity(new StringEntity(modifiedJsonContent));

		// Execute the request and get the response
		HttpResponse response = client.execute(post);

		// Process the response and get the result
		String result = "";
		result = EntityUtils.toString(response.getEntity());
		// Parse the JSON response to extract the 'id' attribute
		JSONObject jsonResponse = new JSONObject(result);
		System.out.println("jsonResponse :"+jsonResponse);
		String name = jsonResponse.optString("name");

		// Return the 'id' attribute value
		return name;
	}

	
	public static String getParentDir() {
		System.out.println("Working Directory : " + System.getProperty("user.dir"));
		System.out.println("Parent : " + Paths.get(System.getProperty("user.dir")).getParent().toString());
		System.out.println("Grand parent : " + Paths.get(System.getProperty("user.dir")).getParent().getParent().toString());
		// for IDE
		return Paths.get(System.getProperty("user.dir")).getParent().getParent().toString();
		// for jar file
		// return Paths.get(System.getProperty("user.dir")).getParent().toString();

	}

}
