package com.kpmg.iga.migration.idn;

import java.io.IOException;
import java.net.URISyntaxException;

import com.kpmg.iga.migration.idn.source.SourceOperations;
import com.kpmg.iga.migration.idn.util.*;

import org.apache.http.client.ClientProtocolException;

public class IDNRESTOperations {

	public static void main(String[] args) throws ClientProtocolException, URISyntaxException, IOException {
		
		//getting access token
		String token = Util.getToken(Util.getProperty("destination.baseUrl"));
		System.out.println("token :"+token);
		//getting create source id
		String sourceName  = SourceOperations.createSrc(token,Util.getAccountCorForActiveDirectory(token));
		System.out.println(sourceName);
		
		
		// update domain information by passing source id
		//System.out.println(Util.updateDomainConfig(token, "36d85a5bc8fa40998d7169488b8c290d"));
		
		//update correlation data
		//System.out.println(Util.updateCorrelationConfig(Util.getProperty("sessionAccessToken"),
			//	"36d85a5bc8fa40998d7169488b8c290d"));
		
		
		String sourceID =  Util.getSourceID(token,sourceName);
		System.out.println("sourceID :"+sourceID);
		
		String accountSchemaID = Util.getAccountSchemaID(token,sourceName);
		System.out.println("accountSchemaID :"+accountSchemaID);
		
		String output = Util.updateSchema(token,sourceID,accountSchemaID);
		System.out.println("output :"+output);
		
		
	}
	


}
